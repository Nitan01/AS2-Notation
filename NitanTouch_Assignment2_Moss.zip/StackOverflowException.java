package application;

/**
 * Exception thrown when attempting to push onto a full stack.
 * 
 * Author: Nitan
 */
public class StackOverflowException extends Exception {

    /** 
     * Default constructor that provides a standard error message.
     */
    public StackOverflowException() {
        this("This stack is full! you can not push!");
    }

    /**
     * Constructor that allows a custom error message.
     *
     * @param msg Custom message for the exception
     */
    public StackOverflowException(String msg) {
        super(msg);
    }
}

