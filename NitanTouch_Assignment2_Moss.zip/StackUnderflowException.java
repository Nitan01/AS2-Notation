package application;

/**
 * Exception thrown when attempting to pop or top an empty stack.
 * 
 * Author: Nitan
 */
public class StackUnderflowException extends Exception {

    /** 
     * Default constructor that provides a standard error message.
     */
    public StackUnderflowException() {
        this("This stack is empty!");
    }

    /**
     * Constructor that allows a custom error message.
     *
     * @param msg Custom message for the exception
     */
    public StackUnderflowException(String msg) {
        super(msg);
    }
}