package application;

import java.util.ArrayList;

/**
 * NotationQueue is a data structure that implements a queue using First In, First Out (FIFO) logic.
 * Items are added to the end and removed from the front.
 * 
 * Author: Nitan
 * 
 * @param <T> The type of data to store in the NotationQueue
 */
public class NotationQueue<T> implements QueueInterface<T> {

    private final int MAX_SIZE;
    private int numOfElements;
    private T[] elements;

    /**
     * Default constructor that initializes the queue with a maximum size of 5.
     */
    public NotationQueue() {
        this(5);
    }

    /**
     * Constructor that initializes the queue with a specified size.
     * 
     * @param size The maximum number of elements the queue can hold
     */
    @SuppressWarnings("unchecked")
    public NotationQueue(int size) {
        MAX_SIZE = size;
        numOfElements = 0;
        elements = (T[]) new Object[MAX_SIZE];
    }

    /**
     * Constructor that populates the queue with elements from an ArrayList.
     * 
     * @param elements An ArrayList to be converted to a NotationQueue
     */
    public NotationQueue(ArrayList<T> elements) {
        this(elements.size());
        for (T element : elements) {
            try {
                enqueue(element);
            } catch (QueueOverflowException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    /**
     * Checks if the queue is empty.
     * 
     * @return True if the queue is empty, false otherwise
     */
    @Override
    public boolean isEmpty() {
        return numOfElements == 0;
    }

    /**
     * Checks if the queue is full.
     * 
     * @return True if the queue is full, false otherwise
     */
    @Override
    public boolean isFull() {
        return numOfElements == MAX_SIZE;
    }

    /**
     * Removes and returns the front item from the queue.
     * 
     * @return The item removed from the front of the queue
     * @throws QueueUnderflowException If the queue is empty
     */
    @Override
    public T dequeue() throws QueueUnderflowException {
        if (isEmpty()) {
            throw new QueueUnderflowException();
        }

        T element = elements[0];
        numOfElements--;

        // Shift elements to the left
        for (int i = 0; i < numOfElements; i++) {
            elements[i] = elements[i + 1];
        }

        return element;
    }

    /**
     * Returns the number of elements in the queue.
     * 
     * @return The current size of the queue
     */
    @Override
    public int size() {
        return numOfElements;
    }

    /**
     * Adds an item to the end of the queue.
     * 
     * @param e The item to be added
     * @return True if the item is successfully added
     * @throws QueueOverflowException If the queue is full
     */
    @Override
    public boolean enqueue(T e) throws QueueOverflowException {
        if (isFull()) {
            throw new QueueOverflowException();
        }

        elements[numOfElements++] = e;
        return true;
    }

    /**
     * Returns a string representation of the queue with no delimiters.
     * 
     * @return A string of all items in the queue
     */
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < numOfElements; i++) {
            result.append(elements[i]);
        }
        return result.toString();
    }

    /**
     * Returns a string representation of the queue with a specified delimiter.
     * 
     * @param delimiter The delimiter used to separate items
     * @return A string of all items in the queue separated by the delimiter
     */
    @Override
    public String toString(String delimiter) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < numOfElements; i++) {
            result.append(elements[i]);
            if (i < numOfElements - 1) {
                result.append(delimiter);
            }
        }
        return result.toString();
    }

    /**
     * Fills the queue with elements from an ArrayList.
     * 
     * @param list An ArrayList to be added to the queue
     */
    @Override
    public void fill(ArrayList<T> list) {
        for (T element : list) {
            try {
                enqueue(element);
            } catch (QueueOverflowException e) {
                System.err.println(e.getMessage());
                break;
            }
        }
    }
}