package application;

/**
 * Exception thrown when attempting to enqueue into a full queue.
 * 
 * Author: Nitan
 */
public class QueueOverflowException extends Exception {

    /** 
     * Default constructor that provides a standard error message.
     */
    public QueueOverflowException() {
        this("This queue is full! YOu can not enqueue!");
    }

    /**
     * Constructor that allows a custom error message.
     *
     * @param msg Custom message for the exception
     */
    public QueueOverflowException(String msg) {
        super(msg);
    }
}