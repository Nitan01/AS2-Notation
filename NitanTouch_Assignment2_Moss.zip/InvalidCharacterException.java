package application;

/**
 * Exception thrown when an invalid character is used in an infix or postfix expression.
 * 
 * Author: Nitan
 */
public class InvalidCharacterException extends Exception {

    /**
     * Default constructor that creates an exception with a default message.
     */
    public InvalidCharacterException() {
        this("Invalid character detected! Please use numbers or +, -, *, / only.");
    }

    /**
     * Constructor that creates an exception with a custom message.
     * 
     * @param msg The custom message for the exception
     */
    public InvalidCharacterException(String msg) {
        super(msg);
    }
}