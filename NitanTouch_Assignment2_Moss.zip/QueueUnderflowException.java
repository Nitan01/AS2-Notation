package application;

/**
 * Exception thrown when attempting to dequeue from an empty queue.
 * 
 * Author: Nitan
 */
public class QueueUnderflowException extends Exception {

    /** 
     * Default constructor that provides a standard error message.
     */
    public QueueUnderflowException() {
        this("This queue is empty! YOu can not dequeue!");
    }

    /**
     * Constructor that allows a custom error message.
     *
     * @param msg Custom message for the exception
     */
    public QueueUnderflowException(String msg) {
        super(msg);
    }
}