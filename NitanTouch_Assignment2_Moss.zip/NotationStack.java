package application;

import java.util.ArrayList;

/**
 * NotationStack is a stack data structure that follows Last In, First Out (LIFO).
 * It supports pushing elements onto the stack and popping them off.
 * You can also view the stack contents as a string using the toString methods.
 * 
 * Author: Nitan
 * 
 * @param <T> The type of data to store in the NotationStack
 */
public class NotationStack<T> implements StackInterface<T> {

    private int numOfElements;
    private final int MAX_SIZE;
    private T[] elements;

    /**
     * Default constructor that initializes the stack with a maximum size of 5.
     */
    public NotationStack() {
        this(5);
    }

    /**
     * Constructor that initializes the stack with a specified size.
     * 
     * @param size The maximum size of the stack
     */
    @SuppressWarnings("unchecked")
    public NotationStack(int size) {
        MAX_SIZE = size;
        elements = (T[]) new Object[MAX_SIZE];
        numOfElements = 0;
    }

    /**
     * Constructor that initializes the stack and fills it with elements from an ArrayList.
     * 
     * @param elements An ArrayList of elements to be added to the stack
     */
    public NotationStack(ArrayList<T> elements) {
        this(elements.size());
        for (T element : elements) {
            try {
                push(element);
            } catch (StackOverflowException e) {
                System.err.println(e.getMessage());
            }
        }
    }

    /**
     * Checks if the stack is empty.
     * 
     * @return True if the stack is empty, false otherwise
     */
    @Override
    public boolean isEmpty() {
        return numOfElements == 0;
    }

    /**
     * Checks if the stack is full.
     * 
     * @return True if the stack is full, false otherwise
     */
    @Override
    public boolean isFull() {
        return numOfElements == MAX_SIZE;
    }

    /**
     * Removes and returns the top item from the stack.
     * 
     * @return The item removed from the top of the stack
     * @throws StackUnderflowException If the stack is empty
     */
    @Override
    public T pop() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException();
        }
        return elements[--numOfElements];
    }

    /**
     * Returns the top item from the stack without removing it.
     * 
     * @return The top item of the stack
     * @throws StackUnderflowException If the stack is empty
     */
    @Override
    public T top() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException();
        }
        return elements[numOfElements - 1];
    }

    /**
     * Returns the number of elements in the stack.
     * 
     * @return The current size of the stack
     */
    @Override
    public int size() {
        return numOfElements;
    }

    /**
     * Adds an item to the top of the stack.
     * 
     * @param e The item to be added
     * @return True if the item is successfully added
     * @throws StackOverflowException If the stack is full
     */
    @Override
    public boolean push(T e) throws StackOverflowException {
        if (isFull()) {
            throw new StackOverflowException();
        }
        elements[numOfElements++] = e;
        return true;
    }

    /**
     * Returns a string representation of the stack with no delimiters.
     * 
     * @return A string of all items in the stack
     */
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < numOfElements; i++) {
            result.append(elements[i]);
        }
        return result.toString();
    }

    /**
     * Returns a string representation of the stack with a specified delimiter.
     * 
     * @param delimiter The delimiter to separate items
     * @return A string of all items in the stack separated by the delimiter
     */
    @Override
    public String toString(String delimiter) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < numOfElements; i++) {
            result.append(elements[i]);
            if (i < numOfElements - 1) {
                result.append(delimiter);
            }
        }
        return result.toString();
    }

    @Override
    public void fill(ArrayList<T> list) {
        // TODO: Implement the method
    }
}