package application;

/**
 * Exception thrown when a notation format is invalid.
 * 
 * Author: Nitan
 */
public class InvalidNotationFormatException extends Exception {

    /**
     * Default constructor that creates an exception with no additional message.
     */
    public InvalidNotationFormatException() {
        this("Invalid notation format.");
    }

    /**
     * Constructor that creates an exception with a custom message.
     * 
     * @param msg The custom message for the exception
     */
    public InvalidNotationFormatException(String msg) {
        super(msg);
    }
}